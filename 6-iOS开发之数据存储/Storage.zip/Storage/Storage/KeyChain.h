//
//  KeyChain.h
//  Storage
//
//  Created by bjhl on 16/9/10.
//  Copyright © 2016年 bjhl. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Security/Security.h>

@interface KeyChain : NSObject

+ (void)save:(NSString *)service account:(NSString *)acc data:(NSData *)data;
+ (void)save:(NSString *)service data:(NSData *)data;

+ (NSData *)load:(NSString *)service;
+ (NSData *)load:(NSString *)service account:(NSString *)acc;

+ (void)delete:(NSString *)service;
+ (void)delete:(NSString *)service account:(NSString *)acc;

@end
