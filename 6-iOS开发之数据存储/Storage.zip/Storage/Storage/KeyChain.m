//
//  KeyChain.m
//  Storage
//
//  Created by bjhl on 16/9/10.
//  Copyright © 2016年 bjhl. All rights reserved.
//

#import "KeyChain.h"

static NSString * const kPDDictionaryKey = @"com.xxx.dictionaryKey";
static NSString * const kPDKeyChainKey = @"com.xxx.keychainKey";

@implementation KeyChain

+ (NSMutableDictionary *)getKeychainQuery:(NSString *)service account:(NSString *)acc {
    NSMutableDictionary *dicx = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                 (id)kSecClassGenericPassword,(id)kSecClass,
                                 nil];
    if (acc) {
        dicx[(id)kSecAttrAccount]=acc;
    }
    if (service) {
        dicx[(id)kSecAttrService]=service;
    }
    return dicx;
}

+ (void)save:(NSString *)service account:(NSString *)acc data:(NSData *)data {
    NSMutableDictionary *keychainQuery = [self getKeychainQuery:service account:acc];
    SecItemDelete((CFDictionaryRef)keychainQuery);
    [keychainQuery setObject:data forKey:(id)kSecValueData];
    SecItemAdd((CFDictionaryRef)keychainQuery, NULL);
}

+ (void)save:(NSString *)service data:(id)data {
    [[self class] save:service account:nil data:data];
}

+ (NSData *)load:(NSString *)service account:(NSString *)acc {
    NSData *ret = nil;
    NSMutableDictionary *keychainQuery = [self getKeychainQuery:service account:acc];
    [keychainQuery setObject:(id)kCFBooleanTrue forKey:(id)kSecReturnData];
    [keychainQuery setObject:(id)kSecMatchLimitOne forKey:(id)kSecMatchLimit];
    CFDataRef keyData = NULL;
    if (SecItemCopyMatching((CFDictionaryRef)keychainQuery, (CFTypeRef *)&keyData) == noErr) {
        ret = (__bridge NSData*)keyData;
    }
    if (keyData)
        CFRelease(keyData);
    return ret;
}

+ (NSData *)load:(NSString *)service {
    return [[self class] load:service account:nil];
}

+ (void)delete:(NSString *)service {
    return [[self class] delete:service account:nil];
}

+ (void)delete:(NSString *)service account:(NSString *)acc {
    NSMutableDictionary *keychainQuery = [self getKeychainQuery:service account:acc];
    SecItemDelete((CFDictionaryRef)keychainQuery);
}

@end
