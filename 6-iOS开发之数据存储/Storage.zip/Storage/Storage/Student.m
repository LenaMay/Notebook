//
//  Student.m
//  Storage
//
//  Created by bjhl on 16/9/8.
//  Copyright © 2016年 bjhl. All rights reserved.
//

#import "Student.h"

@implementation Student

+ (instancetype)testStudent {
    return [[Student alloc] initTestStudent];
}

- (instancetype)initTestStudent {
    if (self = [super init]) {
        self.studentId = 1000;
        self.age = 18;
        self.name = @"王二";
        self.sign = YES;
    }
    return self;
}

- (NSString*)description {
    NSString* sign = self.sign ? @"YES" : @"NO";
    return [NSString stringWithFormat:@"id: %lld, name: %@ , age: %ld , sign: %@", self.studentId, self.name, (long)self.age, sign];
}

#pragma mark - NSCoding

- (void)encodeWithCoder:(NSCoder *)aCoder {
    [aCoder encodeObject:self.name forKey:@"name"];
    [aCoder encodeInteger:self.age forKey:@"age"];
    [aCoder encodeBool:self.sign forKey:@"sign"];
    [aCoder encodeInt64:self.studentId forKey:@"studentId"];
}

- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder {
    if (self = [super init]) {
        self.name = [aDecoder decodeObjectForKey:@"name"];
        self.age = [aDecoder decodeIntegerForKey:@"age"];
        self.sign = [aDecoder decodeBoolForKey:@"sign"];
        self.studentId = [aDecoder decodeInt64ForKey:@"studentId"];
    }
    return self;
}

@end
