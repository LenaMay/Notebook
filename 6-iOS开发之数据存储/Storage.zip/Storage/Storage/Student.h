//
//  Student.h
//  Storage
//
//  Created by bjhl on 16/9/8.
//  Copyright © 2016年 bjhl. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MTLModel.h"

@interface Student :  NSObject <NSCoding> //MTLModel

+ (instancetype)testStudent;

@property (nonatomic, copy) NSString* name;
@property (nonatomic, assign) long long studentId;
@property (nonatomic, assign) NSInteger age;
@property (nonatomic, assign) BOOL sign;

@end
