//
//  AppDelegate.m
//  Storage
//
//  Created by bjhl on 16/9/8.
//  Copyright © 2016年 bjhl. All rights reserved.
//

#import "AppDelegate.h"
#import "KeyChain.h"
#import "Student.h"
#import "FMDB.h"
#import "sqlite3.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {

    [self topic_File];
    [self topic_NSUserDefualts];
    [self topic_NSKeyedArchiver];
    [self topic_SQLite];
    [self topic_KeyChain];
    
    return YES;
}

- (void)topic_File {
    // 获取沙盒主目录路径
//    NSString* homeDir = NSHomeDirectory();
    // 获取Documents目录路径
    NSString* docDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    // 获取Library的目录路径
//    NSString* libDir = [NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES) firstObject];
    // 获取Caches目录路径
//    NSString* cachesDir = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) firstObject];
    // 获取tmp目录路径
//    NSString* tmpDir =  NSTemporaryDirectory();
    
    NSString* testDirPath = [docDir stringByAppendingPathComponent:@"test"];
    NSString* testFilePath = [testDirPath stringByAppendingPathComponent:@"test.txt"];
    
    //创建文件夹
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if (![fileManager fileExistsAtPath:testDirPath isDirectory:nil]) {
        BOOL createSuc = [fileManager createDirectoryAtPath:testDirPath withIntermediateDirectories:YES attributes:nil error:nil];
        if (createSuc) {
            NSLog(@"create dir success");
        } else {
            NSLog(@"create dir fail");
        }
    }
    
    //创建文件
    if (![fileManager fileExistsAtPath:testFilePath]) {
        BOOL createSuc = [fileManager createFileAtPath:testFilePath contents:nil attributes:nil];
        if (createSuc) {
            NSLog(@"create file success");
        } else {
            NSLog(@"create file fail");
        }
    }
    
    //写文件
    NSString* content = @"iOS 开发之数据存储";
    BOOL writeSuc = [content writeToFile:testFilePath atomically:YES encoding:NSUTF8StringEncoding error:nil];
    if (writeSuc) {
        NSLog(@"write file success");
    }else {
        NSLog(@"write file fail");
    }
    
    //读文件
    NSString *readContent = [NSString stringWithContentsOfFile:testFilePath encoding:NSUTF8StringEncoding error:nil];
    NSLog(@"read content: %@", readContent);
    
    //删除文件
    BOOL delDirSuc = [fileManager removeItemAtPath:testDirPath error:nil];
    if (delDirSuc) {
        NSLog(@"del file success");
    }else {
        NSLog(@"del file fail");
    }
}

- (void)topic_NSUserDefualts {
    //存储基本类型
    NSString* content = @"iOS 开发之数据存储";
    NSUserDefaults* userDefualts = [NSUserDefaults standardUserDefaults];
    [userDefualts setObject:content forKey:@"content"];
    [userDefualts synchronize];
    
    NSString* readContent = [userDefualts objectForKey:@"content"];
    NSLog(@"NSUserDefualts read content: %@", readContent);
    
    //存储自定义类对象
    Student* student = [Student testStudent];
    NSData* data = [NSKeyedArchiver archivedDataWithRootObject:student];
    [userDefualts setObject:data forKey:@"student"];
    [userDefualts synchronize];
    
    NSData* readData = [userDefualts objectForKey:@"student"];
    Student* readStudent = [NSKeyedUnarchiver unarchiveObjectWithData:readData];
    NSLog(@"read Student %@", [readStudent description]);
}

- (void)topic_NSKeyedArchiver {
    NSString* docDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    NSString* archiveFilePath = [docDir stringByAppendingPathComponent:@"archiveFile"];
    
    NSMutableArray* archiveArray = [NSMutableArray new];
    for (int i = 0; i < 3; i++) {
        Student* student = [Student testStudent];
        [archiveArray addObject:student];
    }
    //archive
    [NSKeyedArchiver archiveRootObject:archiveArray toFile:archiveFilePath];
    
    //unarchive
    NSArray* unachivedArray = [NSKeyedUnarchiver unarchiveObjectWithFile:archiveFilePath];
    NSLog(@"unachivedArray : %@", [unachivedArray description]);
}

- (void)topic_SQLite {
    NSString* docPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    NSString* dbPath = [docPath stringByAppendingPathComponent:@"sqlite.db"];
    
    //纯 sqlite 语法
    //打开数据库，创建表
    sqlite3* db;
    const char* path = [dbPath UTF8String];
    if (sqlite3_open(path, &db) == SQLITE_OK) {
        NSLog(@"sqlite open db success");
        char *errMsg;
        const char *sql_stmt = "create table if not exists student (studentId interger primary key, name text, age double, sign interger)";
        if (sqlite3_exec(db, sql_stmt, NULL, NULL, &errMsg) == SQLITE_OK){
            NSLog(@"sqlite create table success");
        } else {
            NSLog(@"sqlite create table fail");
        }
    }
    else {
        NSLog(@"open db fail");
    }
    sqlite3_close(db);
    
    // FMDB 封装
    FMDatabase* fmdb = [FMDatabase databaseWithPath:dbPath];
    [fmdb open];

    //插入 id 为 1000 的学生的信息
    Student* student = [Student testStudent];
    NSString* sql = @"insert into student (studentId, name, age, sign) values (?, ?, ?, ?)";
    NSArray *params = @[@(student.studentId), student.name, @(student.age), @(student.sign)];
    BOOL insertSuc = [fmdb executeUpdate:sql withArgumentsInArray:params];
    if (insertSuc) {
        NSLog(@"fmdb insert success");
    } else {
        NSLog(@"fmdb insert fail");
    }

    //读取 id 为 1000 学生信息
    sql = @"select * from student where studentId = 1000";
    FMResultSet* rs = [fmdb executeQuery:sql];
    if (rs) {
        NSLog(@"fmdb query success");
    } else {
        NSLog(@"fmdb query fail");
    }
    Student* readStudent = [Student new];
    while ([rs next]) {
        readStudent.studentId = [rs longLongIntForColumn:@"studentId"];
        readStudent.age = [rs longLongIntForColumn:@"age"];
        readStudent.name = [rs stringForColumn:@"name"];
        readStudent.sign = [rs boolForColumn:@"sign"];
    }
    NSLog(@"read student: %@", [readStudent description]);
    
    //删除
    sql = @"delete from student where studentId = 1000";
    BOOL delSuc = [fmdb executeUpdate:sql];
    if (delSuc) {
        NSLog(@"fmdb delete success");
    } else {
        NSLog(@"fmdb delete fail");
    }
    [fmdb close];
}

- (void)topic_KeyChain {
    NSDictionary* dict = @{@"account" : @"jack" , @"token" : @"xjjd2j4xxx32323cccc"};
    [KeyChain save:@"tx.storage.login" data:[NSKeyedArchiver archivedDataWithRootObject:dict]];
    
    NSData* readData = [KeyChain load:@"tx.storage.login"];
    NSDictionary* readDict = [NSKeyedUnarchiver unarchiveObjectWithData:readData];
    NSLog(@"read data from keychain: %@", [readDict description]);
}

@end
