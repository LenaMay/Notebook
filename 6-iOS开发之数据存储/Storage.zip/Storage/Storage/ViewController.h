//
//  ViewController.h
//  Storage
//
//  Created by bjhl on 16/9/8.
//  Copyright © 2016年 bjhl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

